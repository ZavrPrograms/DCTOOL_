import requests

def pingPerson(channelId, userId, message, token):
    url = 'https://discord.com/api/v9/channels/{}/messages'.format(channelId)
    header = {"authorization": token}
    data = {"content": "<@{}> {}".format(userId, message)}

    r = requests.post(url, headers=header, data=data)
    print(r.status_code)

pingPerson("1255142458765873233", "1035266907777007727", "HEY ", "MTI1NTEzNzg0NTM3NTUzMzEzOQ.GMCBR7.8M3UrabNlzsl3QUs4Qhoy5NpAr6giXxr7sqmFA")