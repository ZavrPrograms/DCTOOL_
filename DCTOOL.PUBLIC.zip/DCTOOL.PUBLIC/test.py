with open('Input/token.txt', 'r') as file:
    contents = file.readline()
    print(contents.strip())
    print('done!')