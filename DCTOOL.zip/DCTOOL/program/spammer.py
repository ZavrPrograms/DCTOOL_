import requests


def discordmsg(link, token, message):
    payload = {
        'content': message
    }

    header = {
        'authorization': token
    }
    r = requests.post(f"https://discord.com/api/v9/channels/{link}/messages", data=payload, headers=header)

discordmsg('https://discord.com/api/v9/channels/1255142458765873233/messages', 'MTAzNTI2NjkwNzc3NzAwNzcyNw.GVA8PQ.bZC4YUkBQ46n1nVbc3j1zZQFMd1HS9b0CkO5SY', 'test')
print('done!')