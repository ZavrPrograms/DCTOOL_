import requests
from colorama import Fore, Back, Style
import os
from program.spammer import *
from pystyle import Colorate, Colors, Write

def coloredinput(text):
    x = input(Colorate.Horizontal(Colors.blue_to_white, text))

def coloredtext(text):
    print(Colorate.Horizontal(Colors.blue_to_white, text))

def cmd(command):
    os.system(command)

cmd('chcp 65001 >nul')
cmd('cls')

def banner():
    coloredtext(f'''
██████╗  ██████╗████████╗ ██████╗  ██████╗ ██╗     
██╔══██╗██╔════╝╚══██╔══╝██╔═══██╗██╔═══██╗██║     
██║  ██║██║        ██║   ██║   ██║██║   ██║██║     
██║  ██║██║        ██║   ██║   ██║██║   ██║██║     
██████╔╝╚██████╗   ██║   ╚██████╔╝╚██████╔╝███████╗
╚═════╝  ╚═════╝   ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
    ''')

banner()

cmd('title DCTOOL')

coloredtext(f'''     
            [i] Info 
[01] Discord Message
[02] Discord Spam
[03] Discord RAID
''')

x = input('$ ')

if x == '1':
    with open('Input/token.txt', 'r') as file:
        link = input('Channel ID: ')
        message = input('Message: ')
        contents = file.readline()
        discordmsg(link, contents.strip(), message)

elif x == '2':
    with open('Input/token.txt', 'r') as file:
        link = input('Channel ID: ')
        message = input('Message: ')
        contents = file.readline()
        while True:
            discordmsg(link, contents.strip(), message)

elif x == '3':
    link = input('Channel ID: ')
    message = input('Message: ')
    while True:
        with open('Input/token.txt', 'r') as file:
            for line in file:
                contents = line.strip()
                discordmsg(link, contents.strip(), message)
                coloredtext(f'SENT | {message} | {contents}')

elif x == '4':
    coloredtext('Coming soon!')

elif x == 'i' or 'I':
    coloredtext('''

Made by ZAVR
Open source
Made in python


                ''')
    coloredtext('Press any key to continue...')
    cmd('pause >nul')
else:
    print(f'{Fore.RED}OPTION INVALID')
    cmd('pause >nul')
