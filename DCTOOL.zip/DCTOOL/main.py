import requests
from colorama import Fore, Back, Style
import os
from program.spammer import *
from pystyle import Colorate, Colors, Write

tokens = 0

with open('Input/token.txt', 'r') as file:
    for line in file:
        tokens += 1

def coloredinput(text):
    x = input(Colorate.Horizontal(Colors.blue_to_white, text))

def coloredtext(text):
    print(Colorate.Horizontal(Colors.blue_to_white, text))

def greencoloredtext(text):
    print(Colorate.Horizontal(Colors.green_to_white, text))

def cmd(command):
    os.system(command)

cmd('chcp 65001 >nul')
cmd('cls')

def banner():
    coloredtext(f'''
██████╗  ██████╗████████╗ ██████╗  ██████╗ ██╗     
██╔══██╗██╔════╝╚══██╔══╝██╔═══██╗██╔═══██╗██║     
██║  ██║██║        ██║   ██║   ██║██║   ██║██║     
██║  ██║██║        ██║   ██║   ██║██║   ██║██║     
██████╔╝╚██████╗   ██║   ╚██████╔╝╚██████╔╝███████╗
╚═════╝  ╚═════╝   ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
    ''')

banner()

cmd(f'title DCTOOL / {tokens} tokens / By Zavr')

coloredtext(f'''     
            [i] Info 
[01] Message            [05] Controlled channel raider
[02] Channel Spam       [06] Multi-channel Raider
[03] Channel Raider
[04] Fast Raider
''')

x = input('$ ')

if x == '1':
    with open('Input/token.txt', 'r') as file:
        link = input('Channel ID: ')
        message = input('Message: ')
        contents = file.readline()
        coloredtext('Attempting to send...')
        discordmsg(link, contents.strip(), message)

elif x == '2':
    with open('Input/token.txt', 'r') as file:
        link = input('Channel ID: ')
        message = input('Message: ')
        contents = file.readline()
        while True:
            coloredtext('Attempting to send...')
            discordmsg(link, contents.strip(), message)
            cmd('timeout /t 1 /NOBREAK >nul')

elif x == '3':
    link = input('Channel ID: ')
    message = input('Message: ')
    while True:
        with open('Input/token.txt', 'r') as file:
            for line in file:
                coloredtext('Attempting to send...')
                contents = line.strip()
                discordmsg(link, contents.strip(), message)
                greencoloredtext(f'SENT | {message} | {contents}')
                cmd('timeout /t 1 /NOBREAK >nul')

elif x == '4':
    coloredtext('Read before use: This is more buggy so may not work as well [Press any key to continue]')
    cmd('pause >nul')
    link = input('Channel ID: ')
    message = input('Message: ')
    while True:
        with open('Input/token.txt', 'r') as file:
            for line in file:
                coloredtext('Attempting to send...')
                contents = line.strip()
                discordmsg(link, contents.strip(), message)
                greencoloredtext(f'SENT | {message} | {contents}')
                cmd('timeout /t 1 /NOBREAK >nul')

elif x == '5':
    coloredtext('Just so you know, this lets it repeat a certain ammount of times')
    repeat = int(input('Repeat: '))
    link = input('Channel ID: ')
    message = input('Message: ')

    for i in range(repeat):
        with open('Input/token.txt', 'r') as file:
            coloredtext('Attempting to send...')
            contents = line.strip()
            discordmsg(link, contents.strip(), message)
            greencoloredtext(f'SENT | {message} | {contents}')
    greencoloredtext(f'sent {message} {i} times!')
    os.system('pause')

elif x == '6':
    input_list = input("Enter a the challed ids separated by commas: ").split(',')
    message = input('Message: ')
    while True:
        for item in input_list:
            with open('Input/token.txt', 'r') as file:
                for line in file:
                    coloredtext('Attempting to send...')
                    contents = line.strip()
                    discordmsg(item, contents.strip(), message)
                    greencoloredtext(f'SENT | {message} | {contents}')
                    cmd('timeout /t 1 /NOBREAK >nul')


elif x == 'i' or 'I':
    coloredtext('''

Made by ZAVR
Open source
Made in python


                ''')
    coloredtext('Press any key to continue...')
    cmd('pause >nul')

else:
    print(f'{Fore.RED}OPTION INVALID')
    cmd('pause >nul')
